This "Portfolio" assignment's objective was to code in HTML/CSS our own version to match the provided image of a webpage as much as possible.
